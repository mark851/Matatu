# AMATATU website prototype

## Run locally
Open `index.html` in a modern browser.

## Deploy
Upload `index.html` to your hosting `public_html` folder, or import this folder into a GitHub repository and deploy it with Vercel.

## Included
- Responsive mobile-first game interface
- Playable practice game against three computer opponents
- Card matching, draw pile, suit selection, special cards, round scoring
- Rules dialog and basic win tracking for the current browser session

## Important limitations
This is a front-end prototype. It does not include real online multiplayer, accounts, a database, deposits, withdrawals, cash betting or payouts. Those require a secure backend and, for real-money play in Uganda, appropriate regulatory authorisation and approved payment arrangements.
